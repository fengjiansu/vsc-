#include <iostream>
#include <vector>
#include<algorithm>
using namespace std;
using std::vector;
double greedy(vector<int>p)
{
    int n=p.size();
    vector<int>x(n,0);
    sort(p.begin(),p.end());
    int k=(n-1)/2;
    x[k]=p[n-1];
    for(int i=k+1;i<n;i++)
    {
        x[i]=p[n-2*(i-k)];
    }
    for(int i=k-1;i>=0;i--)
    {
        x[i]=p[n-2*(k-i)-1];
    }
    double m=0,t=0;
    for(int i=0;i<n;i++)
    {
        m+=p[i];
        for(int j=i+1;j<n;j++)
        {
            t+=x[i]*x[j]*(j-i);
        }
    }
    return t/m/m;
}
int main()
{
    int n;
    int a;
    double t;
    vector<int>p;
    FILE *fp,*fpOut;
     if((fp=fopen("input.txt","r"))==NULL){
        printf("\nCannot open input file strike any key exit!");
        getchar();
        return -1;
    }
     if((fpOut=fopen("output.txt","w"))==NULL){
        printf("\nCannot open input file strike any key exit!");
        getchar();
        return -1;
    }
   fscanf(fp,"%d",&n);
   for(int i=0;i<n;i++)
    {
        fscanf(fp,"%d",&a);                          //β������
       p.push_back(a);                          //β������
   }
   t=greedy(p);
   cout<<"��С��������ʱ��Ϊ��"<<t<<endl;
fprintf(fpOut,"%lf",t);
fclose(fp);
fclose(fpOut);
    return 0;
}