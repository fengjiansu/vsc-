#include <stdio.h>
#include<math.h>
int  multiple,result=0;
void bubble_sort(int arr[], int len) {
        int i, j, temp;
        for (i = 0; i < len - 1; i++)
                for (j = 0; j < len - 1 - i; j++)
                        if (arr[j] > arr[j + 1]) {
                                temp = arr[j];
                                arr[j] = arr[j + 1];
                                arr[j + 1] = temp;
                        }
}
int median(int *arr,int start,int end )
{
    return arr[(start+end)/2];//��ż��ȡ��ߵ�Ϊ��λ��
}
void split(int*arr,int med,int start,int end,int *startleft,int *endright)//�ҵ���λ���������start1�����Ҷ�end1
{
  for(int i=0;i<end;i++)
  {
      if(arr[i]==med)
      {
          *startleft=i;
          break;
      }
  }
  for(int i=end;i>start;i--)
  {
      if(arr[i]==med)
      {
          *endright=i;
          break;
      }
  }
}
void mode(int *arr,int start,int end)
{
    multiple=end/2;
    int startleft,endright;
    int med=median(arr,start,end);//�ҵ���λ��
    split(arr,med,start,end,&startleft,&endright);//�ҵ���λ����ˣ��Ҷ�
    if(multiple<=endright-startleft+1)
    {
        multiple=endright-startleft+1;//��������
          result=med;
     }
    if(startleft-start>multiple)//�����߸������������ٵݹ�
    mode(arr,start,startleft-1);
    if(end-endright>multiple)//����ұ߸������������ٵݹ�
    mode(arr,endright+1,end);
}
int main()
{
    int num=7;
    int arr[num];
    FILE *fp = NULL;
    fp=fopen("E:\\vsC++\\Althorim\\lab1\\2-1\\input.txt","r");
    for(int i=0;i<num;i++)
    {
     fscanf(fp,"%d",&arr[i]);
    }
    fclose(fp);
   bubble_sort(arr,num);
   mode(arr,0,num-1);
   //printf("%d,%d",result,multiple);
   FILE *fp1 = NULL;
fp1=fopen("E:\\vsC++\\Althorim\\lab1\\2-1\\output.txt","w");
fprintf(fp1,"%d\n%d",result,multiple);
    return 0;
}